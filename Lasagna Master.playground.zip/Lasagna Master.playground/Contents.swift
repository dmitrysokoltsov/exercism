func remainingMinutesInOven(elapsedMinutes: Int,
                            expectedMinutesInOven: Int = 40) -> Int {
    return expectedMinutesInOven - elapsedMinutes
}

func preparationTimeInMinutes(layers: [String],
                              preparationTimeInMinutes: Int = 2) -> Int {
    return layers.count * preparationTimeInMinutes
}


