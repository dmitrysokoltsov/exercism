func remainingMinutesInOven(elapsedMinutes: Int, expectedMinutesInOven: Int = 40) -> Int {

    return expectedMinutesInOven - elapsedMinutes

}

func preparationTimeInMinutes(layers: String...) -> Int {

    guard layers.count != 0 else { return 0 }

    return layers.count * 2

}

func quantities(layers: String...) -> (noodles: Int, sauce: Double) {

    let noodlesCount = layers.filter({$0 == "noodles"}).count

    let sauceCount = layers.filter({$0 == "sauce"}).count

    let noodles = noodlesCount * 3

    let sauceDouble = Double(sauceCount) * 0.2

    // func roundDoubleToTwoDecimals(_ x: Double) -> Double {

    //     let rounded = String(format: "%.1f", x)

    //     return Double(rounded)!

    // }

    // let sauce = roundDoubleToTwoDecimals(sauceDouble)

    let sauce = sauceDouble
    
    return (noodles, sauce)

}

func toOz(_ amount: inout (noodles: Int, sauce: Double)) {
    amount = (noodles: amount.noodles, sauce: amount.sauce * 33.814)
}

func redWine(layers: String...) -> Bool {
    let mozzarellaCount = layers.filter({$0 == "mozzarella"}).count
    let ricottaCount = layers.filter({$0 == "ricotta"}).count
    let béchamelCount = layers.filter({$0 == "béchamel"}).count
    let sauceCount = layers.filter({$0 == "sauce"}).count
    let meatCount = layers.filter({$0 == "meat"}).count
    
    if (mozzarellaCount + ricottaCount + béchamelCount) < (meatCount + sauceCount) {
        return true

    } else if (mozzarellaCount + ricottaCount + béchamelCount) == (meatCount + sauceCount) {

        return true

    } else {

        return false

    }
}
