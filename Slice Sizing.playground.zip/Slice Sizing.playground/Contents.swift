/*
 Implement the function, sliceSize(diameter: Double?, slices: Int?) -> Double?, which, given the diameter of a pizza and the number of slices per pizza returns the area of a slice. For negative diameters and for number of slices less than 1, return nil, as there is no such thing as a pizza with negative diameter and no way to slice a pizza into fewer than 1 slice. If either parameter is nil, also return
 */

func sliceSize(diameter: Double?, slices: Int?) -> Double? {
    guard let diameter = diameter, diameter >= 0, let slices = slices, slices >= 1 else {return nil}
    let radius = diameter / 2
    return radius * radius * Double.pi / Double(slices)
}

func biggestSlice(
  diameterA: String, slicesA: String, diameterB: String, slicesB: String) -> String {
  
}


